#include "greater_than_or_equal.h"

bool greater_than_or_equal(double a, double b) {
    return a >= b;
}
