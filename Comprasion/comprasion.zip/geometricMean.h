#ifndef GEOMETRIC_MEAN_H
#define GEOMETRIC_MEAN_H

double geometricMean(double* array, int size);

#endif