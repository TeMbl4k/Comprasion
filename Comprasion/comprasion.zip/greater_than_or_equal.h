#ifndef GREATER_THAN_OR_EQUAL_H
#define GREATER_THAN_OR_EQUAL_H

bool greater_than_or_equal(double a, double b);
bool greater_than_or_equal(double* array1, int a_size, double* array2, int b_size);

#endif

